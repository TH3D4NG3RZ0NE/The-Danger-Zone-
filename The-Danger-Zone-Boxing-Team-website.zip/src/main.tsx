import React from "react";
import { createRoot } from "react-dom/client";
import { siteContent } from "./content/site-content";
import "./styles.css";

const offer = [
  {
    number: "01",
    title: "TRAINING",
    text: "Build fundamentals, conditioning, movement and boxing skills in a focused team environment.",
    action: "Ask about training",
  },
  {
    number: "02",
    title: "SPARRING",
    text: "Sharpen timing, defense, counters and ring awareness with controlled, purposeful work.",
    action: "Ask about sparring",
  },
  {
    number: "03",
    title: "FIGHTS",
    text: "Interested in competing or booking a fight night? Contact the team to discuss current opportunities.",
    action: "Ask about fights",
  },
];

function contactHref(subject: string) {
  return siteContent.contact.email
    ? `mailto:${siteContent.contact.email}?subject=${encodeURIComponent(subject)}`
    : "#contact";
}

function App() {
  const hasPhone = Boolean(siteContent.contact.phone);
  const hasEmail = Boolean(siteContent.contact.email);
  const hasSocials = Object.values(siteContent.socials).some(Boolean);

  return (
    <div className="site">
      <header className="nav">
        <a className="brand" href="#top" aria-label="The Danger Zone Boxing Team home">
          <img src="/team-mark.png" alt="" />
          <span>DANGER ZONE</span>
        </a>
        <nav aria-label="Primary">
          <a href="#team">Team</a>
          <a href="#offer">What We Do</a>
          <a href="#events">Events</a>
          <a className="nav-cta" href="#contact">CONTACT</a>
        </nav>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-grid" />
          <div className="hero-copy">
            <p className="eyebrow">BOXING TEAM • {siteContent.sponsorName}</p>
            <h1>THE<br /><span>DANGER ZONE</span><br />BOXING TEAM</h1>
            <p className="hero-sub">TRAIN. SPAR. FIGHT.</p>
            <p className="sponsor">Sponsored by <strong>{siteContent.sponsorName}</strong></p>
            <div className="actions">
              <a className="button button-accent" href="#contact">JOIN / TRAIN</a>
              <a className="button button-ghost" href="#events">VIEW EVENTS</a>
            </div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="ring">
              <i /><i /><i /><i />
              <div className="rope rope-1" /><div className="rope rope-2" /><div className="rope rope-3" />
            </div>
            <div className="glove">DZ</div>
          </div>
          <div className="scroll">SCROLL <span>↓</span></div>
        </section>

        <section id="team" className="section intro">
          <div className="section-label">WHO WE ARE</div>
          <div>
            <h2>BUILT FOR THE<br /><em>WORK.</em></h2>
            <p>The Danger Zone Boxing Team is a boxing team training through E-Ville Boxing Gym. The team is built around training, sparring and opportunities to compete, with a simple focus: show up, put in the work and keep sharpening your skills.</p>
            <p className="muted">No invented records. No hype about titles that haven't been supplied. Just a place to learn, train and pursue boxing.</p>
          </div>
        </section>

        <section id="offer" className="section dark-section">
          <div className="section-label">WHAT WE OFFER</div>
          <div className="offer-grid">
            {offer.map((item) => (
              <article className="offer" key={item.title}>
                <span className="offer-number">{item.number}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
                <a href={contactHref(item.action)}>{item.action} <span>↗</span></a>
              </article>
            ))}
          </div>
        </section>

        <section id="events" className="section events">
          <div className="section-label">SCHEDULE / EVENTS</div>
          <div className="empty-state">
            <div className="empty-mark">DZ</div>
            <div>
              <h2>UPCOMING ACTION<br /><em>IS BEING CONFIRMED.</em></h2>
              <p>Upcoming bouts and training times are being confirmed. Get in touch for the current schedule.</p>
              {siteContent.trainingTimes ? <p><strong>Training:</strong> {siteContent.trainingTimes}</p> : null}
              <a className="text-link" href="#contact">GET THE CURRENT SCHEDULE →</a>
            </div>
          </div>
        </section>

        <section id="contact" className="section contact">
          <div className="contact-heading">
            <div className="section-label">CONTACT</div>
            <h2>READY TO<br /><em>STEP IN?</em></h2>
            <p>Want to train, join the team, spar, or book a fight night? Reach out and the team can provide the current details.</p>
          </div>
          <div className="contact-card">
            {hasEmail ? (
              <a className="contact-row" href={`mailto:${siteContent.contact.email}`}>
                <span>EMAIL</span><strong>{siteContent.contact.email}</strong><b>↗</b>
              </a>
            ) : (
              <div className="contact-row placeholder"><span>EMAIL</span><strong>Contact email coming soon</strong><b>—</b></div>
            )}
            {hasPhone ? (
              <a className="contact-row" href={`tel:${siteContent.contact.phone.replace(/\D/g, "")}`}>
                <span>PHONE</span><strong>{siteContent.contact.phone}</strong><b>↗</b>
              </a>
            ) : (
              <div className="contact-row placeholder"><span>PHONE</span><strong>Contact phone coming soon</strong><b>—</b></div>
            )}
            <div className="contact-row">
              <span>SPONSOR</span><strong>{siteContent.sponsorName}</strong><b>✓</b>
            </div>
            <div className="contact-note">
              <strong>Owner setup:</strong> add the live email and phone once in <code>src/content/site-content.ts</code>. Every contact button will use those details automatically.
            </div>
          </div>
        </section>
      </main>

      <footer>
        <div className="footer-top">
          <div>
            <div className="footer-name">THE DANGER ZONE<br />BOXING TEAM</div>
            <p>Sponsored by <strong>{siteContent.sponsorName}</strong></p>
          </div>
          <div className="footer-nav">
            <a href="#team">Team</a><a href="#offer">What We Do</a><a href="#events">Events</a><a href="#contact">Contact</a>
          </div>
          <div className="socials">
            {hasSocials ? Object.entries(siteContent.socials).filter(([,url])=>url).map(([name,url]) => <a key={name} href={url} target="_blank" rel="noreferrer">{name}</a>) : <span>Social links coming soon</span>}
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} The Danger Zone Boxing Team</span>
          <span>Sponsored by E-Ville Boxing Gym</span>
        </div>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
